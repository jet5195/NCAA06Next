This folder is for the NCAA 06 NEXT BETA V3 ISO MOD.

Please move this folder to REPLACEMENTS.

After that, remove HOFSTRA and NORTHEASTERN from /REPLACEMENTS/TEAMS/COLONIAL  or /REPLACEMENTS/TEAMS/FCS/